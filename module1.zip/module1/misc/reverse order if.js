<html>
<head>
<script>
for (var i=10;1>=0;i--)
{document.write ("number order is"+ i)
}
</script>
</head>
<body>

</body>
</html>
